const AWS = require('aws-sdk');
const s3 = new AWS.S3();

exports.handler = async (event) => {
    const operation = event.operation;
    
    switch (operation) {
        case 'PUT':
            const putParams = {
                Bucket: process.env.S3_BUCKET,
                Key: event.filename,
                Body: new Buffer(event.content, 'base64'),
                ContentType: 'image/jpeg' 
            };
            await s3.putObject(putParams).promise();
            break;
            
        case 'GET':
            const getParams = {
                Bucket: process.env.S3_BUCKET,
                Key: event.filename
            };
            const data = await s3.getObject(getParams).promise();
            return data.Body.toString('base64');
            
        default:
            throw new Error(`Unsupported operation "${operation}"`);
    }
}
